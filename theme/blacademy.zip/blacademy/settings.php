<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Moodle's Blacademy theme, an example of how to make a Bootstrap theme
 *
 * DO NOT MODIFY THIS THEME!
 * COPY IT FIRST, THEN RENAME THE COPY AND MODIFY IT INSTEAD.
 *
 * For full information about creating Moodle themes, see:
 * http://docs.moodle.org/dev/Themes_2.0
 *
 * @package   theme_blacademy
 * @copyright 2013 Moodle, moodle.org
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$settings = null;

defined('MOODLE_INTERNAL') || die;
global $PAGE;

$ADMIN->add('themes', new admin_category('theme_blacademy', 'Blacademy'));

/* General Settings */
    $temp = new admin_settingpage('theme_blacademy_generic',  get_string('geneicsettings', 'theme_blacademy'));
    
    // Logo file setting.
    $name = 'theme_blacademy/logo';
    $title = get_string('logo','theme_blacademy');
    $description = get_string('logodesc', 'theme_blacademy');
    $setting = new admin_setting_configstoredfile($name, $title, $description, 'logo');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $temp->add($setting);
    
    // Footnote setting.
    $name = 'theme_blacademy/footnote';
    $title = get_string('footnote', 'theme_blacademy');
    $description = get_string('footnotedesc', 'theme_blacademy');
    $default = '';
    $setting = new admin_setting_confightmleditor($name, $title, $description, $default);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $temp->add($setting);

    // Custom CSS file.
    $name = 'theme_blacademy/customcss';
    $title = get_string('customcss', 'theme_blacademy');
    $description = get_string('customcssdesc', 'theme_blacademy');
    $default = '';
    $setting = new admin_setting_configtextarea($name, $title, $description, $default);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $temp->add($setting);
    
    // Invert Navbar to dark background.
    $name = 'theme_blacademy/invert';
    $title = get_string('invert', 'theme_blacademy');
    $description = get_string('invertdesc', 'theme_blacademy');
    $setting = new admin_setting_configcheckbox($name, $title, $description, 0);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $temp->add($setting);
    
    $ADMIN->add('theme_blacademy', $temp);
    
    
/* Banner Settings */
    $temp = new admin_settingpage('theme_blacademy_frontpagebanner',  get_string('frontpagebanner', 'theme_blacademy'));

// Headerimg file setting.
$name = 'theme_blacademy/headerimg';
$title = get_string('headerimg', 'theme_blacademy');
$description = get_string('headerimgdesc', 'theme_blacademy');
$setting = new admin_setting_configstoredfile($name, $title, $description, 'headerimg');
$setting->set_updatedcallback('theme_reset_all_caches');
$temp->add($setting);

// Bannerheading.

// Headerimg file setting.
$name = 'theme_blacademy/headerimg';
$title = get_string('headerimg', 'theme_blacademy');
$description = get_string('headerimgdesc', 'theme_blacademy');
$setting = new admin_setting_configstoredfile($name, $title, $description, 'headerimg');
$setting->set_updatedcallback('theme_reset_all_caches');
$temp->add($setting);

$name = 'theme_blacademy/bannerheading';
$title = get_string('bannerheading', 'theme_blacademy');
$description = get_string('bannerheadingdesc', 'theme_blacademy');
$default = 'Perfect Learning System';
$setting = new admin_setting_configtext($name, $title, $description, $default);
$setting->set_updatedcallback('theme_reset_all_caches');
$temp->add($setting);

// Bannercontent.
$name = 'theme_blacademy/bannercontent';
$title = get_string('bannercontent', 'theme_blacademy');
$description = get_string('bannercontentdesc', 'theme_blacademy');
$default = 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.';
$setting = new admin_setting_configtextarea($name, $title, $description, $default);
$setting->set_updatedcallback('theme_reset_all_caches');
$temp->add($setting);

// Banner Font color.
$name = 'theme_blacademy/bannerfontcolor';
$title = get_string('bannerfontcolor', 'theme_blacademy');
$description = get_string('bannerfontcolordesc', 'theme_blacademy');
$default = '#ffffff';
$setting = new admin_setting_configcolourpicker($name, $title, $description, $default);
$temp->add($setting);

    $ADMIN->add('theme_blacademy', $temp);

    
/* Social Network Settings */
$temp = new admin_settingpage('theme_blacademy_social', get_string('socialsettings', 'theme_blacademy'));
    $temp->add(new admin_setting_heading('theme_blacademy_social', get_string('socialheadingsub', 'theme_blacademy'),
        format_text(get_string('socialdesc', 'theme_blacademy'), FORMAT_MARKDOWN)));

    // Facebook url setting.
    $name = 'theme_blacademy/facebook';
    $title = get_string('facebook', 'theme_blacademy');
    $description = get_string('facebookdesc', 'theme_blacademy');
    $default = '';
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $temp->add($setting);

    // Flickr url setting.
    $name = 'theme_blacademy/flickr';
    $title = get_string('flickr', 'theme_blacademy');
    $description = get_string('flickrdesc', 'theme_blacademy');
    $default = '';
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $temp->add($setting);

    // Twitter url setting.
    $name = 'theme_blacademy/twitter';
    $title = get_string('twitter', 'theme_blacademy');
    $description = get_string('twitterdesc', 'theme_blacademy');
    $default = '';
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $temp->add($setting);

    // LinkedIn url setting.
    $name = 'theme_blacademy/linkedin';
    $title = get_string('linkedin', 'theme_blacademy');
    $description = get_string('linkedindesc', 'theme_blacademy');
    $default = '';
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $temp->add($setting);

    // Pinterest url setting.
    $name = 'theme_blacademy/pinterest';
    $title = get_string('pinterest', 'theme_blacademy');
    $description = get_string('pinterestdesc', 'theme_blacademy');
    $default = '';
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $temp->add($setting);

    // YouTube url setting.
    $name = 'theme_blacademy/youtube';
    $title = get_string('youtube', 'theme_blacademy');
    $description = get_string('youtubedesc', 'theme_blacademy');
    $default = '';
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $temp->add($setting);
	
    
    $ADMIN->add('theme_blacademy', $temp);
